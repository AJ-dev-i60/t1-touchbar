# Handoff: t1bar studio — main window redesign (wireframe stage)

## Overview
**t1bar studio** is the settings + design surface for a MacBook Touch Bar (a 2170×60 px
OLED strip) driven on Linux by a background service. The app edits one JSON config; a
service renders it onto the real hardware and hot-reloads on save, so every edit appears on
the physical Touch Bar within ~1 second. The emotional hook is *"I changed this and it's
already live on my laptop."*

This handoff covers the **information-architecture redesign** of the main window, explored as
wireframes. A recommended direction has been chosen (see Fidelity → Recommended direction).

## About the Design Files
The file in this bundle (`TouchBar Studio Wireframes.dc.html`) is a **design reference created
in HTML** — a low-fidelity wireframe canvas showing structure, layout, and flow. It is **not
production code to copy**. The task is to **recreate the chosen layout in the target codebase's
environment**.

> ⚠️ Platform note: the real app is a **native Linux desktop app — GTK4 + libadwaita +
> PyGObject (Python), with Cairo for custom drawing (the bar preview & weight ruler)**. There
> is **no web / no browser / no local server** (explicit hard requirement). The HTML wireframe
> is only a layout reference. Implement with GTK4/libadwaita widgets + custom CSS/Cairo
> drawing. Dark theme, Wayland, HiDPI. Fonts: Inter (installed) + a mono face.

## Fidelity
**Low-fidelity (lofi) wireframes.** Use them as a guide for **layout, IA, and functionality** —
not for final styling. Apply the app's calm, Apple-grade, native-feeling visual system at
implementation time (restrained color, generous spacing, content-first; "Shortcuts × Final Cut
inspector"). The sketchy hand-drawn look, the Kalam/Architects-Daughter fonts, the muted blue,
and the offset drop-shadows in the wireframe are **wireframe conventions only — discard them.**

The wireframe file lays out three IA explorations plus the chosen synthesis. Only the synthesis
needs to be built.

### ★ Recommended direction (the one to build)
Labeled **"★ Refined direction → Combined main window"** in the file. It combines:
- **Full-width bar preview as the hero**, in a dark OLED "pit", spanning the window width,
  with a **weight ruler** strip directly beneath it (relative widths per widget).
- **Left rail organized around layouts + rules** (the "rules-first" IA): a stack of **layout
  cards** (each showing a mini render of its own bar, with a "live / editing" badge), then a
  **rules ladder** (first-match-wins, with the currently-matching rule highlighted).
- **Center inspector** for the current selection (Item / Theme / Rules tabs).
- **Right-side widget palette** you **drag onto the bar** (a gap opens where the widget lands).

## Screens / Views

There is one primary screen: the **main window**. It is a single resizable desktop window
(~1340×800 today). Regions top-to-bottom:

### 1. Header / chrome
- **Purpose:** app identity + global state toggles.
- **Layout:** horizontal bar. Left: window controls. Center: title "t1bar studio". Right: two
  pill toggles.
- **Components:**
  - **"▶ preview playing"** toggle — simulates the media-playing state in the *preview only*
    (affects play/pause icon, scrubber fill, bound labels). Must read as a simulation, not the
    real state.
  - **"● live on bar"** indicator — shows the background service is connected and edits are
    applying to hardware. Has a connected (dot lit) vs not-connected state. When not connected,
    the app stays fully usable as a design tool (preview only) and says so calmly.

### 2. Bar preview (HERO) + weight ruler
- **Purpose:** faithful render of the Touch Bar; the trust anchor ("this is your real bar").
  Also the **primary editing surface** (select, drag-to-reorder, drag handles to resize weight,
  drop target for new widgets).
- **Layout:** full window width. A dark pit (near-black, inset shadow) containing a single
  horizontal row of widgets sized by **weight** (flex-grow proportional). A small caption line
  above ("YOUR TOUCH BAR · 2170×60 · editing 'default'" on the left; an "● applied to hardware"
  status on the right). Directly below the pit: the **weight ruler** — one tick segment per
  widget, segment width proportional to weight, labeled with the weight number; the selected
  widget's segment is accented.
- **Components / behavior:**
  - **Faithful render:** correct 2170×60 aspect intent (long thin ribbon), real theme colors,
    real icons/fonts. Uses the same renderer as the hardware (Cairo).
  - **Widgets:** button (label *or* icon), scrubber (progress + tap-to-seek), label (static or
    live-bound text), spacer (invisible flexible gap).
  - **Selection:** selected widget gets a visible accent outline; selecting it fills the center
    inspector. A right-edge **drag handle** on the selected widget resizes its weight.
  - **Drop target:** dragging a widget from the palette opens a dashed "drop" gap at the
    insertion point.
  - **Active-layout note:** caption states which layout is being edited; this may differ from
    which layout is *live* on the bar (see rules).

### 3. Left rail — Layouts + Rules
- **Purpose:** answer "which layouts exist, which is live, and why." This is the primary nav.
- **Layout:** fixed-width left column (~248px in the wireframe), two stacked sections.
- **Components:**
  - **LAYOUTS** (section label) → vertical stack of **layout cards**. Each card: layout name,
    a small "● live · editing" / plain badge, and a **mini render of that layout's bar**.
    The active/edited card is accented. Last item: a dashed **"+ new layout"** card.
    Cards support: select-to-edit, rename, delete, duplicate.
  - **RULES · first match wins** (section label) → vertical list of rule rows, each
    `⋮ when <condition> → <layout>`, with a drag handle (`⋮`) to reorder. The
    **currently-matching** rule is highlighted with a "◀ now" marker. The last rule is the
    catch-all `otherwise → <layout>` (a rule with no condition). A dashed **"+ add rule"** row
    at the bottom.
  - **Conditions** available when building a rule: `media playing` (today). Leave room for
    future `app focused…` and `CPU / GPU load…` conditions (shown as dashed/disabled chips).

### 4. Center — Inspector
- **Purpose:** edit the current selection. Three tabs: **Item / Theme / Rules**.
- **Layout:** flexible center column. Tab strip top-right; fields below in a 2-column grid.
- **Item tab (selected widget):**
  - **label** (text field) and **icon** (picker; a button shows *either* label or icon).
  - **weight** — a **slider** with the numeric value as secondary (direct-manipulation
    preferred over raw numbers). Mirrors the drag handle on the preview.
  - **fill** — color editing, the **most-used action; make it excellent**: a row of swatches
    (recent / used colors + theme palette) plus a real picker. The selected swatch is accented.
    Must show **per-button override vs theme default** legibly ("· overriding theme") with a
    **"reset"** affordance to fall back to the theme color. (Schema stores RGB triples — hide
    that from the UI.)
  - **action** — an **approachable categorized picker** (Key / Media / Volume / Brightness /
    Layout-switch), NOT raw `KEY_*` typing. Shows current value (e.g. "⌨ Key · ESC") with a
    "change ▾".
- **Theme tab:** global bar fields — background, button fill/text/radius/font_size, pressed
  fill+color, accent, scrubber track, gap, margin. Color pickers for RGB fields; numeric/slider
  for radius/font_size/gap/margin.
- **Rules tab:** full rule editing (the left-rail list is the compact view).
- **Empty state:** when nothing is selected, the inspector shows Theme (or an empty hint).

### 5. Right — Widget palette
- **Purpose:** add widgets to the current layout.
- **Layout:** fixed-width right column (~172px).
- **Components:** "WIDGETS" label + four draggable items: **Button**, **Scrubber**, **Label**,
  **Spacer** (spacer styled as dashed/secondary). A caption: "drag up onto the bar — a gap opens
  where it lands."
- **Behavior:** **drag from the rail onto the bar preview** (region 2). The bar shows a live
  insertion gap; dropping inserts the widget there.

## Interactions & Behavior
- **Live loop:** all edits autosave (debounced) and apply to hardware within ~1s. Surface a
  subtle "applied" feedback near the live indicator — reassuring, never nagging.
- **Direct manipulation on the preview:** drag to reorder widgets; drag a right-edge handle to
  resize a widget's weight; drag a palette item in to add; click empty area to add.
- **Selection → inspector:** clicking a widget on the bar selects it and populates the Item tab.
- **Rules:** evaluated top→bottom, first match wins; highlight the matching row so the user
  understands *why* the bar currently shows what it shows. Reorder via drag handles.
- **Preview-state toggle:** "preview playing" simulates media state in the preview only
  (play/pause icon swaps, scrubber fills, bound labels populate). Clearly a simulation.
- **Undo / redo / revert:** support undo-redo and revert-to-last-saved / reset-to-default.
- **Keyboard:** select, nudge, delete, duplicate, undo.
- **Errors:** an invalid value must not break the bar; surface gently (renderer is defensive).

## State Management
- **config** (the JSON in §Data model below) is the single source of truth; mutations are
  debounced-saved and hot-reloaded onto hardware.
- **selectedWidgetId** + **editingLayoutName** — drive the inspector and the preview's edit
  context.
- **activeLayoutName** — which layout is *live* on the bar right now (derived from rules +
  current context); may differ from editingLayoutName.
- **previewPlaying** (bool) — preview-state simulation toggle.
- **liveConnected** (bool) — service/hardware connection status.
- **undo/redo stacks**.
- **Live context sources:** media (status playing; live title/artist/position/length). Planned:
  focused-app, system stats.

## Data model (implement to these exact fields)
```jsonc
{
  "version": 1,
  "theme": {
    "background": [R,G,B],
    "button": { "fill":[R,G,B], "text":[R,G,B], "radius":12, "font_size":26 },
    "pressed": { "fill":[R,G,B], "color":[R,G,B] },
    "accent":  [R,G,B],            // scrubber fill / highlights
    "track":   [R,G,B],            // scrubber empty-track
    "gap": 10, "margin": 10
  },
  "layouts": {
    "default": { "items": [ <widget>, ... ] },
    "media":   { "items": [ ... ] }
  },
  "rules": [
    { "when": { "media": "playing" }, "show": "media" },
    { "show": "default" }          // no "when" = fallback
  ]
}
```
**Widget types** (each has optional `id`, numeric `weight`):
- `button` — `label` *or* `icon`; optional `fill`/`color` overrides; optional
  `dynamic:"play_pause"`; `action`.
- `spacer` — `weight` only.
- `label` — `source` (e.g. `media_title`), `font_size`.
- `scrubber` — `source:"media_position"`, `action:["seek"]`.

**Icons today:** play, pause, prev, next, brightness_up, brightness_down, volume_up,
volume_down, volume_mute, fullscreen, + simple text-glyph icons (extensible).

**Actions:** `["key","KEY_X"]`, `["seek"]`, `["media", …]`, `["layout","name"]`
(switch layout for ~10s).

## Design Tokens (lofi — final values TBD at hifi stage)
The wireframe deliberately avoids final styling. At implementation, derive tokens from the app's
native dark theme. Known constraints:
- **Theme:** dark, native (libadwaita). Restrained color; accent reserved for selection/live.
- **Typography:** Inter (UI) + a mono face (technical labels / numbers).
- **The bar pit:** near-black background, inset shadow to read as an OLED recess.
- **Spacing:** generous, Apple-calm.
- Layout column widths from the wireframe (~248px left rail, ~172px palette, flexible center)
  are starting points, not specs — make it degrade gracefully as the window resizes.

## Assets
None bundled. Icons are the renderer's named vector glyphs (see icon list above); use the app's
existing icon set. The bar preview & weight ruler are **custom-drawn (Cairo)**, not images.

## Files
- `TouchBar Studio Wireframes.dc.html` — the wireframe canvas. Open in a browser. Contains:
  - **Section 1 — Overall layout & IA:** approaches A (stage three-pane), B (pit-hero), C
    (rules-first). *Context only.*
  - **Section 2 — Profiles & rules:** 2a rule ladder, 2b flow view, 2c layout cards.
  - **Section 3 — Widget palette:** 3a drag-from-rail, 3b inline "+" popover, 3c tray.
  - **★ Refined direction — Combined main window:** **the chosen design to build** (C's rail +
    A's full-width preview & ruler + 2c layout cards + 3a drag).
